<?php

return array (
  'singular' => 'صفحة',
  'plural' => 'الصفحات',
  'fields' =>
  array (
    'id' => 'الرمز التعريفي',
    'language' => 'الغة',
    'active' => 'نشط',
    'in_navbar' => 'In Navbar',
    'in_footer' => 'In Footer',
    'name' => 'الاسم',
    'content' => 'المحتوي',
    'slug' => 'الرابط',
    'created_at' => 'تاريخ الانشاء',
    'updated_at' => 'تاريخ التعديل',
  ),
);
