<?php

return array(
  'singular' => 'الرسالة',
  'plural' => 'الرسائل',
  'fields' =>
  array(
    'id' => 'الرمز التعريفي',
    'name' => 'الاسم',
    'type' => 'النوع',
    'email' => 'البريد الاكتروني',
    'subject' => 'الموضوع',
    'message' => 'الرسالة',
    'created_at' => 'تاريخ الانشاء',
    'updated_at' => 'تاريخ التعديل',
  ),
);
