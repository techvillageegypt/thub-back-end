<?php

return array(
  'singular' => 'سلة التسوق',
  'plural' => 'سالات التسوق',
  'noProducts' => 'سلة التسوق فارغة.',
  'fields' =>
  array(
    'id' => 'الرمز التعريفي',
    'user_id' => 'الرمز التعريفي للمستخدم',
  ),
);
