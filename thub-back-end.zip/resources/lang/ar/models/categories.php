<?php

return array (
  'singular' => 'الفئة',
  'plural' => 'الفئات',
  'fields' =>
  array (
    'id' => 'الرمز التعريفي',
    'name' => 'الاسم',
    'photo' => 'الصورة',
    'status' => 'الحالة',
    'type' => 'النوع',
  ),
);
