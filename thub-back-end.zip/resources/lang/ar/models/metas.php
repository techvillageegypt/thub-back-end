<?php

return array (
  'singular' => 'محركات البحث',
  'plural' => 'محركات البحث',
  'fields' =>
  array (
    'id' => 'الرمز التعريفي',
    'language' => 'الغة',
    'title' => 'العنوان',
    'description' => 'الوصف',
    'keywords' => 'الكلمات الدالة',
    'page' => 'الصفحة',
    'status' => 'الحالة',
    'created_at' => 'تاريخ الانشاء',
    'updated_at' => 'تاريخ التعديل',
  ),
);
