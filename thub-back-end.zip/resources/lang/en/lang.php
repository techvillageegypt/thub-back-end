<?php

use Symfony\Component\HttpKernel\Profiler\Profile;

return [

    //////////////////////////////////////////////////////////////
    ////////////////////////// 4GO ///////////////////////////////
    //////////////////////////////////////////////////////////////

    // A a

    'active' => 'Active',
    'all' => 'All',
    'accountNotActive' => 'account not active',
    'approved' => 'Approved',
    '' => '',

    // B b

    '' => '',
    '' => '',

    // C c

    'currency' => 'UAE',
    '' => '',
    '' => '',

    // D d

    'deactivate' => 'Deactivate',
    '' => '',

    // E e

    '' => '',
    '' => '',

    // F f

    '' => '',
    '' => '',

    // G g

    '' => '',
    '' => '',

    // H h

    '' => '',
    '' => '',

    // I i
    'inactive' => 'Inactive',
    'in_progress' => 'In progress',
    '' => '',

    // J j

    '' => '',
    '' => '',

    // K k

    '' => '',
    '' => '',

    // L l
    'logoutMsg' => 'Successfully logged out',
    '' => '',
    '' => '',

    // M m

    '' => '',
    '' => '',

    // N n

    'no' => 'No',
    '' => '',

    // O o

    'options' => 'Options',
    '' => '',
    '' => '',

    // P p

    'pending' => 'Pending',
    '' => '',

    // Q q

    '' => '',
    '' => '',

    // R r

    'rejected' => 'Rejected',
    '' => '',

    // S s

    'select' => 'Select',
    'status' => 'Status',
    '' => '',

    // T t

    '' => '',
    '' => '',

    // U u

    '' => '',
    '' => '',

    // V v

    '' => '',
    '' => '',

    // W w
    'wrongCredential' => 'wrong email or password',
    'wrongOldPassword' => 'old password not correct',
    '' => '',
    '' => '',

    // X x

    '' => '',
    '' => '',

    // Y y
    'your_code' => 'your code is : :model',
    'yes' => 'Yes',
    '' => '',
    '' => '',

    // Z z

    '' => '',
    '' => '',
];
