<?php

return array(
    'singular' => 'Category',
    'plural' => 'Categories',
    'fields' =>
    array(
        'id' => 'ID',
        'parent_id' => 'Parent',
        'name' => 'Name',
        'brief' => 'Brief',
        'status' => 'Status',

        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
