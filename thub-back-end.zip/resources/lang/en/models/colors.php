<?php

return array (
  'singular' => 'Color',
  'plural' => 'Colors',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'hex' => 'Hex',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
