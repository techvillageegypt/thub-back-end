<?php

return array (
  'singular' => 'Page',
  'plural' => 'Pages',
  'fields' =>
  array (
    'id' => 'ID',
    'language' => 'Language',
    'active' => 'Active',
    'in_navbar' => 'In Navbar',
    'in_footer' => 'In Footer',
    'name' => 'Name',
    'content' => 'Content',
    'slug' => 'URL',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
