<?php

return array(
    'singular' => 'Blog',
    'plural' => 'Blogs',
    'fields' =>
    array(
        'id' => 'ID',
        'photo' => 'Photo',
        'title' => 'Title',
        'brief' => 'Brief',
        'description' => 'Description',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
