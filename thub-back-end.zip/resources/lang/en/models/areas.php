<?php

return array (
  'singular' => 'Area',
  'plural' => 'Areas',
  'fields' =>
  array (
    'id' => 'ID',
    'text' => 'Text',
    'status' => 'Status',
  ),
);
