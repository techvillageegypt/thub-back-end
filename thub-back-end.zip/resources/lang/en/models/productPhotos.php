<?php

return array (
  'singular' => 'ProductPhoto',
  'plural' => 'ProductPhotos',
  'fields' => 
  array (
    'id' => 'Id',
    'product_id' => 'Product Id',
    'photo' => 'Photo',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
