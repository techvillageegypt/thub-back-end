<?php

return array (
  'singular' => 'Role',
  'plural' => 'Roles',
  'fields' =>
  array (
    'id' => 'ID',
    'name' => 'Name',
    'bulck_select' => 'Bulck Select',
  ),
);
