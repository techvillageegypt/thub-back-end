<?php

return array (
  'singular' => 'Information',
  'plural' => 'Information',
  'fields' =>
  array (
    'id' => 'ID',
    'name' => 'Name',
    'value' => 'Value',
    'status' => 'Status',
  ),
);
