<?php

return array (
  'singular' => 'Size',
  'plural' => 'Sizes',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
