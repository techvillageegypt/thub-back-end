<?php

return array(
    'singular' => 'Message',
    'plural' => 'Messages',
    'fields' =>
    array(
        'id' => 'ID',
        'name' => 'Name',
        'type' => 'Type',
        'phone' => 'Phone',
        'email' => 'Email',
        'subject' => 'Subject',
        'message' => 'Message',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
