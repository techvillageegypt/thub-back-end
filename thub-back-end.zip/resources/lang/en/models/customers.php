<?php

return array (
  'singular' => 'Customer',
  'plural' => 'Customers',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'phone' => 'Phone',
    'email' => 'Email',
    'password' => 'Password',
    'photo' => 'Photo',
    'status' => 'Status',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
