<?php

return array (
  'singular' => 'ProductReview',
  'plural' => 'ProductReviews',
  'fields' =>
  array (
    'id' => 'ID',
    'pharmacy_id' => 'Pharmacy Id',
    'product_id' => 'Product Id',
    'rate' => 'Rate',
  ),
);
