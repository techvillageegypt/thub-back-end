<?php

return array (
  'singular' => 'images',
  'plural' => 'images',
  'fields' => 
  array (
    'id' => 'Id',
    'page_id' => 'Page',
    'photo' => 'Photo',
  ),
);
