<?php

return array (
  'singular' => 'ProductSize',
  'plural' => 'ProductSizes',
  'fields' => 
  array (
    'id' => 'Id',
    'product_id' => 'Product Id',
    'size' => 'Size',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
