<?php

return array (
  'singular' => 'Ads',
  'plural' => 'Ads',
  'fields' =>
  array (
    'id' => 'ID',
    'photo' => 'Photo',
    'width' => 'Width',
    'height' => 'Height',
    'page' => 'Page',
    'link' => 'Link',
  ),
);
