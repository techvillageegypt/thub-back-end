<?php

return array (
  'singular' => 'Newsletter',
  'plural' => 'Newsletters',
  'fields' =>
  array (
    'id' => 'ID',
    'email' => 'Email',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
