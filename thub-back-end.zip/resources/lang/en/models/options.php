<?php

return array(
    'singular'  => 'Option',
    'plural'    => 'Options',
    'fields'    =>
    array(
        'id'                                => 'Id',
        'created_at'                        => 'Created At',
        'updated_at'                        => 'Updated At',
        'logo'                              => 'Logo',
        'fav_icon'                          => 'Fav Icon',
        'welcome_message'                   => 'Welcome Message',
        'welcome_photo'                     => 'Welcome Photo',
    ),
);
