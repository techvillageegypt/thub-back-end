@extends('layouts.app')

@section('content')
  <div class="container-fluid">
        <div class="animated fadeIn">
             <div class="row">

            </div>
        </div>
    </div>
</div>
@endsection
