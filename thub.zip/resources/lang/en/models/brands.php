<?php

return array(
    'singular' => 'Brand',
    'plural' => 'Brands',
    'fields' =>
    array(
        'id' => 'Id',
        'logo' => 'Logo',
        'text' => 'Text',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
