<?php

return array(
    'singular' => 'State',
    'plural' => 'States',
    'fields' =>
    array(
        'id' => 'Id',
        'name' => 'Name',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
