<?php

return array(
    'singular' => 'Social Link',
    'plural' => 'Social Links',
    'fields' =>
    array(
        'id' => 'Id',
        'name' => 'Name',
        'link' => 'Link',
        'status' => 'Status',
    ),
);
