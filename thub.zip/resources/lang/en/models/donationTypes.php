<?php

return array(
    'singular' => 'DonationType',
    'plural' => 'DonationTypes',
    'fields' =>
    array(
        'id' => 'Id',
        'name' => 'Name',
        'icon' => 'Icon',
        'web_icon' => 'Web Icon',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
