<?php

return array(
    'singular' => 'App Feature',
    'plural' => 'App Features',
    'fields' =>
    array(
        'id' => 'Id',
        'icon' => 'Icon',
        'text' => 'Text',
        'description' => 'Description',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
