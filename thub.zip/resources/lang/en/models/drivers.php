<?php

return array(
    'singular' => 'Driver',
    'plural' => 'Drivers',
    'fields' =>
    array(
        'id' => 'Id',
        'name' => 'Name',
        'phone' => 'Phone',
        'verify_code' => 'Verify Code',
        'state' => 'State',
        'address' => 'Address',
        'housing_type' => 'Housing Type',
        'house_number' => 'House Number',
        'building_number' => 'Building Number',
        'floor_number' => 'Floor Number',
        'apartment_number' => 'Apartment Number',


        'status' => 'Status',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);


    // 'name',
    //     'address',
    //     'housing_type',
    //     'house_number',
    //     'state_id',
    //     'building_number',
    //     'floor_number',
    //     'apartment_number',
