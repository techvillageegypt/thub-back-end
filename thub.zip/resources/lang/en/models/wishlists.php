<?php

return array(
  'singular' => 'Wishlist',
  'plural' => 'Wishlists',
  'fields' =>
  array(
    'id' => 'ID',
    'user_id' => 'User Id',
    'product_title' => 'Product Name',
  ),
);
