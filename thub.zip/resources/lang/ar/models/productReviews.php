<?php

return array (
  'singular' => 'تقيم المنتج',
  'plural' => 'تقيمات المنتج',
  'fields' =>
  array (
    'id' => 'الرمز التعريفي',
    'pharmacy_id' => 'الرمز التعريفي للصيدلية',
    'product_id' => 'الرمز التعريفي للمنتج',
    'rate' => 'معدل',
  ),
);
