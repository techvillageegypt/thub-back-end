<?php

return array (
  'singular' => 'الدور',
  'plural' => 'الادوار',
  'fields' =>
  array (
    'id' => 'الرمز التعريفي',
    'name' => 'الاسم',
    'bulck_select' => 'تحديد الكل',
  ),
);
