<?php

return array(
  'singular' => 'Slider',
  'plural' => 'Sliders',
  'fields' =>
  array(
    'id' => 'الرمز التعريفي',
    'photo' => 'الصورة',
    'title' => 'العنوان',
    'description' => 'الوصف',
    'button_text' => 'نص الزرار',
    'link' => 'الرابط',
    'status' => 'الحالة',
    'sort' => 'ترتيب',
    'created_at' => 'تاريخ الانشاء',
    'updated_at' => 'تاريخ التعديل',
  ),
);
