<?php

return array (
  'singular' => 'المدير',
  'plural' => 'المديرين',
  'fields' =>
  array (
    'id' => 'الرمز التعريفي',
    'name' => 'الاسم',
    'email' => 'البريد الاكتروني',
    'password' => 'كلمة السر',
    'password_confirmation' => 'تاكيد كلمة السر',
    'roles' => 'الادوار',
    'status' => 'الحالة',
    'remember_token' => 'تذكر الرمز',
    'created_at' => 'تاريخ الانشاء',
    'updated_at' => 'تاريخ التعديل',
  ),
);
