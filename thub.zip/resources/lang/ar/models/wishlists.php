<?php

return array(
  'singular' => 'المفضلة',
  'plural' => 'المفضالات',
  'fields' =>
  array(
    'id' => 'الرمز التعريفي',
    'user_id' => 'الرمز التعريفي للمستخدم',
    'product_title' => 'اسم المنتج',
  ),
);
