<?php

return  [
    'chooseCompany' => 'اختيار الشركة',
    'choosePage' => 'اختيار الصفحة',
    'viewSpecs' => 'عرض المساحة'
];
